function filtered = demosaicBilinear(img)

% demosaicBilinear demosaics a Bayer filtered image
%
% Input:
% img - NxMx3 matrix of uint8 with Bayer filtered image
%
% Output:
% filtered - NxMx3 matrix of uint8 with interpolated image that fills in
%           missing pixel values

filtered = 0;  % DELETE THIS you need to fill in this variable

% Uncomment the next 5 lines
% img = im2double(img);
% red = img(:,:,1);
% green = img(:,:,2);
% blue = img(:,:,3);
% [x y z] = size(img)

% Fill in the reds

% Fill in the blues

% Fill in the greens


