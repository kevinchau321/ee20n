function filtered = demosaicPDI(img)

%% Demosaic by using adjacent, non-overlapping squares of 4 pixels, called
%% Pixel Doubling Interpolation
% Input: 
% img - NxMx3 matrix of uint8 with Bayer filtered image
%
% Output:
% filtered - NxMx3 matrix of uint8 with interpolated image that fills in
%           missing pixel values

filtered = 0; % DELETE THIS LINE, You need to fill in this variable


% Fill in the reds


% Fill in the blues


% Fill in the greens

